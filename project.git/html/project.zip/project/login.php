<?php

$usr = $_POST['usr'];

$pwd = $_POST['pwd'];

$chk = "";

if(isset($_POST['chk_box']))
	$chk = $_POST['chk_box'];



echo $usr.'<br>';

echo $pwd.'<br>';

echo $chk.'<br>';





?>
